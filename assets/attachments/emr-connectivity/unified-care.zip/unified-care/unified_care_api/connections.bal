import ballerinax/health.clients.fhir.cerner;
import ballerinax/health.clients.fhir.epic;

final epic:FHIRClientConnector epicClient = check new ({
    baseURL: epicBaseUrl,
    authConfig: {clientId: epicClientId, tokenEndpoint: epicTokenUrl, keyFile: epicKeyFile},
    timeout: 90
});

final cerner:FHIRClientConnector cernerClient = check new ({
    baseURL: cernerBaseUrl,
    authConfig: {tokenUrl: cernerTokenUrl, clientId: cernerClientId, clientSecret: cernerClientSecret, scopes: cernerScopes},
    timeout: 90
});
