import ballerinax/health.fhir.r4;

// Builds a FHIR OperationOutcome indicating that the requested Patient was not found.
isolated function buildNotFoundOutcome(string diagnostics) returns r4:OperationOutcome {
    return {
        resourceType: "OperationOutcome",
        issue: [
            {
                severity: r4:CODE_SEVERITY_ERROR,
                code: r4:PROCESSING_NOT_FOUND,
                diagnostics: diagnostics
            }
        ]
    };
}

// Builds a FHIR OperationOutcome indicating that the upstream repository
// is unreachable or returned an unexpected error.
isolated function buildBadGatewayOutcome(string diagnostics) returns r4:OperationOutcome {
    return {
        resourceType: "OperationOutcome",
        issue: [
            {
                severity: r4:CODE_SEVERITY_FATAL,
                code: r4:TRANSIENT_EXCEPTION,
                diagnostics: diagnostics
            }
        ]
    };
}
