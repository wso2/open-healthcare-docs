// Port the UnifiedCare API listens on.
configurable int servicePort = 9095;

// Epic sandbox: SMART Backend Services (private key JWT client assertion).
configurable string epicBaseUrl = "https://fhir.epic.com/interconnect-fhir-oauth/api/FHIR/R4";
configurable string epicTokenUrl = "https://fhir.epic.com/interconnect-fhir-oauth/oauth2/token";
configurable string epicClientId = ?;
configurable string epicKeyFile = ?;

// Cerner sandbox: system app (OAuth2 client credentials).
configurable string cernerBaseUrl = "https://fhir-ehr-code.cerner.com/r4/ec2458f2-1e24-41c8-b71b-0e701af7583d";
configurable string cernerTokenUrl = "https://authorization.cerner.com/tenants/ec2458f2-1e24-41c8-b71b-0e701af7583d/protocols/oauth2/profiles/smart-v1/token";
configurable string cernerClientId = ?;
configurable string cernerClientSecret = ?;
configurable string[] cernerScopes = [
    "system/Patient.read",
    "system/Condition.read",
    "system/Observation.read",
    "system/AllergyIntolerance.read",
    "system/MedicationRequest.read"
];
