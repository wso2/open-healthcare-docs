import ballerina/http;
import ballerina/log;

# UnifiedCare — cross-EMR patient access API.
# Every patient operation fans out to Epic and Cerner in parallel and combines
# whatever each EMR returns, using system-to-system SMART Backend Services auth.
service /unifiedcare on new http:Listener(servicePort, timeout = 300) {

    # Looks a patient id up in ALL connected EMRs and combines the results.
    #
    # + patientId - patient logical id (Epic or Cerner)
    # + return - combined lookup result, or 404 when no EMR has the patient
    resource function get patients/[string patientId]()
            returns UnifiedPatientResult|http:NotFound {
        UnifiedPatientResult unifiedResult = lookupPatientEverywhere(patientId = patientId);
        if unifiedResult.foundIn.length() == 0 {
            return <http:NotFound>{
                body: <ErrorBody>{
                    message: string `Patient '${patientId}' was not found in any connected EMR`
                }
            };
        }
        return unifiedResult;
    }

    # Searches patients by demographics across ALL connected EMRs and merges the matches.
    #
    # + family - family name to search
    # + given - given name to search
    # + birthdate - date of birth (YYYY-MM-DD)
    # + return - merged search results, or an error response
    resource function get patients(string? family, string? given, string? birthdate)
            returns UnifiedSearchResult|http:BadRequest {
        if family is () && given is () && birthdate is () {
            return <http:BadRequest>{
                body: <ErrorBody>{message: "Provide at least one of: family, given, birthdate"}
            };
        }
        log:printInfo("Fanning out patient search to Epic and Cerner",
                family = family, given = given, birthdate = birthdate);
        future<PatientSummary[]|error> epicFuture = start searchPatients(emr = EPIC,
                family = family, given = given, birthdate = birthdate);
        future<PatientSummary[]|error> cernerFuture = start searchPatients(emr = CERNER,
                family = family, given = given, birthdate = birthdate);

        string[] foundIn = [];
        PatientSummary[] combinedPatients = [];
        string[] warnings = [];
        PatientSummary[]|error epicMatches = wait epicFuture;
        if epicMatches is PatientSummary[] {
            if epicMatches.length() > 0 {
                foundIn.push(EPIC);
                combinedPatients.push(...epicMatches);
            }
        } else {
            warnings.push(string `epic: ${epicMatches.message()}`);
        }
        PatientSummary[]|error cernerMatches = wait cernerFuture;
        if cernerMatches is PatientSummary[] {
            if cernerMatches.length() > 0 {
                foundIn.push(CERNER);
                combinedPatients.push(...cernerMatches);
            }
        } else {
            warnings.push(string `cerner: ${cernerMatches.message()}`);
        }
        log:printInfo("Combined search results ready", totalMatches = combinedPatients.length(),
                foundIn = foundIn.toString());
        return {foundIn, patients: combinedPatients, warnings};
    }

    # Builds a cross-EMR Patient-360. Resolves the id in all EMRs, aggregates the
    # clinical summary wherever it resolves, then links the same person in the
    # other EMR by demographics and aggregates there too.
    #
    # + patientId - patient logical id (Epic or Cerner)
    # + return - combined clinical view, or an error response
    resource function get patients/[string patientId]/summary()
            returns UnifiedPatient360|http:NotFound|http:InternalServerError {
        UnifiedPatient360|error unified360 = buildUnifiedPatient360(patientId = patientId);
        if unified360 is error {
            if unified360.message().includes("not found in any connected EMR") {
                return <http:NotFound>{body: <ErrorBody>{message: unified360.message()}};
            }
            log:printError("Unified Patient-360 aggregation failed", 'error = unified360, patientId = patientId);
            return <http:InternalServerError>{body: <ErrorBody>{message: unified360.message()}};
        }
        return unified360;
    }

    # Initiates a cross-EMR referral: pulls the clinical record from the source
    # EMR and looks for the same patient in the target EMR by demographics.
    #
    # + referralRequest - referral instruction
    # + return - transition-of-care packet, or an error response
    resource function post referrals(ReferralRequest referralRequest)
            returns ReferralPacket|http:BadRequest|http:InternalServerError {
        if referralRequest.sourceEmr == referralRequest.targetEmr {
            return <http:BadRequest>{body: <ErrorBody>{message: "sourceEmr and targetEmr must differ"}};
        }
        ReferralPacket|error referralPacket = processReferral(referralRequest = referralRequest);
        if referralPacket is error {
            log:printError("Referral processing failed", 'error = referralPacket);
            return <http:InternalServerError>{body: <ErrorBody>{message: referralPacket.message()}};
        }
        return referralPacket;
    }
}
