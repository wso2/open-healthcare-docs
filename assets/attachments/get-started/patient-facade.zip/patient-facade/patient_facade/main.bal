import ballerina/http;
import ballerinax/health.clients.fhir;
import ballerinax/health.fhir.r4;
import ballerinax/health.fhir.r4.international401;

const string FHIR_JSON_CONTENT_TYPE = "application/fhir+json";

service /fhir/r4 on new http:Listener(9091) {

    // Reads a single Patient from the repository by id and applies facade changes.
    resource function get Patient/[string id]() returns http:Response {
        fhir:FHIRResponse|fhir:FHIRServerError|fhir:FHIRConnectorError result = fhirServerClient->getById("Patient", id);

        if result is fhir:FHIRServerError {
            int statusCode = result.detail().httpStatusCode;
            if statusCode == 404 {
                return buildOutcomeResponse(buildNotFoundOutcome(string `Patient/${id} not found`), 404);
            }
            return buildOutcomeResponse(buildBadGatewayOutcome(string `Repository returned an error for Patient/${id}`), 502);
        }

        if result is fhir:FHIRConnectorError {
            return buildOutcomeResponse(buildBadGatewayOutcome(string `Repository is unreachable for Patient/${id}`), 502);
        }

        json|xml resourcePayload = result.'resource;
        international401:Patient|error patient = trap resourcePayload.cloneWithType(international401:Patient);
        if patient is error {
            return buildOutcomeResponse(buildBadGatewayOutcome(string `Repository returned an invalid Patient payload for Patient/${id}`), 502);
        }

        international401:Patient changedPatient = applyFacadeChanges(patient);
        return buildJsonResponse(changedPatient.toJson(), 200);
    }

    // Searches Patients in the repository, forwarding all query parameters,
    // and applies facade changes to each entry of the resulting searchset Bundle.
    resource function get Patient(http:Request request) returns http:Response {
        map<string[]> searchParameters = request.getQueryParams();

        fhir:FHIRResponse|fhir:FHIRServerError|fhir:FHIRConnectorError result =
            fhirServerClient->search("Patient", searchParameters = searchParameters);

        if result is fhir:FHIRServerError {
            return buildOutcomeResponse(buildBadGatewayOutcome("Repository returned an error for Patient search"), 502);
        }

        if result is fhir:FHIRConnectorError {
            return buildOutcomeResponse(buildBadGatewayOutcome("Repository is unreachable for Patient search"), 502);
        }

        json|xml resourcePayload = result.'resource;
        r4:Bundle|error bundle = trap resourcePayload.cloneWithType(r4:Bundle);
        if bundle is error {
            return buildOutcomeResponse(buildBadGatewayOutcome("Repository returned an invalid Bundle payload for Patient search"), 502);
        }

        r4:BundleEntry[]? entries = bundle.entry;
        if entries is r4:BundleEntry[] {
            r4:BundleEntry[] changedEntries = [];
            foreach r4:BundleEntry entry in entries {
                r4:BundleEntry|error changedEntry = applyFacadeChangesToEntry(entry);
                if changedEntry is error {
                    changedEntries.push(entry);
                    continue;
                }
                changedEntries.push(changedEntry);
            }
            bundle.entry = changedEntries;
        }

        r4:Bundle rewrittenBundle = rewriteBundleUrls(bundle);
        return buildJsonResponse(rewrittenBundle.toJson(), 200);
    }
}

// Builds an http:Response carrying the given JSON payload as application/fhir+json.
isolated function buildJsonResponse(json payload, int statusCode) returns http:Response {
    http:Response response = new;
    response.statusCode = statusCode;
    response.setJsonPayload(payload);
    response.setHeader("Content-Type", FHIR_JSON_CONTENT_TYPE);
    return response;
}

// Builds an http:Response carrying the given OperationOutcome as application/fhir+json.
isolated function buildOutcomeResponse(r4:OperationOutcome outcome, int statusCode) returns http:Response {
    return buildJsonResponse(outcome.toJson(), statusCode);
}
