// Configuration for the FHIR Patient API facade.

// Base URL of the upstream WSO2 FHIR Server repository.
configurable string fhirServerUrl = "http://localhost:9090/fhir/r4";

// Base URL at which this facade itself is exposed, used to rewrite
// repository URLs in search Bundle links and entry fullUrls.
configurable string facadeBaseUrl = "http://localhost:9091/fhir/r4";
