import ballerinax/health.fhir.r4;
import ballerinax/health.fhir.r4.international401;

// Applies all facade transformations to a single Patient resource:
// - removes US-SSN identifiers
// - masks phone numbers in telecom
// - tags the resource with the facade's source meta tag
isolated function applyFacadeChanges(international401:Patient patient) returns international401:Patient {
    r4:Identifier[]? identifiers = patient.identifier;
    if identifiers is r4:Identifier[] {
        patient.identifier = from r4:Identifier identifier in identifiers
            where identifier.system != US_SSN_IDENTIFIER_SYSTEM
            select identifier;
    }

    r4:ContactPoint[]? telecom = patient.telecom;
    if telecom is r4:ContactPoint[] {
        patient.telecom = from r4:ContactPoint contactPoint in telecom
            select maskIfPhone(contactPoint);
    }

    r4:Meta? meta = patient.meta;
    r4:Coding facadeTag = {system: FACADE_TAG_SYSTEM, code: FACADE_TAG_CODE};
    if meta is r4:Meta {
        r4:Coding[]? tags = meta.tag;
        if tags is r4:Coding[] {
            tags.push(facadeTag);
            meta.tag = tags;
        } else {
            meta.tag = [facadeTag];
        }
        patient.meta = meta;
    } else {
        patient.meta = {tag: [facadeTag]};
    }

    return patient;
}

// Masks a phone number contact point so only the last 4 digits remain visible.
// Non-phone contact points are returned unchanged.
isolated function maskIfPhone(r4:ContactPoint contactPoint) returns r4:ContactPoint {
    r4:ContactPointSystem? system = contactPoint.system;
    string? value = contactPoint.value;
    if system == r4:phone && value is string {
        contactPoint.value = maskPhoneNumber(value);
    }
    return contactPoint;
}

// Masks all but the last 4 characters of a phone number, preserving any
// non-alphanumeric separators (e.g. "123-456-4412" -> "***-***-4412").
isolated function maskPhoneNumber(string phoneNumber) returns string {
    int length = phoneNumber.length();
    int visibleStart = length - 4;
    if visibleStart < 0 {
        visibleStart = 0;
    }

    string masked = "";
    foreach int i in 0 ..< length {
        string currentChar = phoneNumber.substring(i, i + 1);
        if i >= visibleStart {
            masked += currentChar;
        } else if currentChar.matches(re `[0-9]`) {
            masked += "*";
        } else {
            masked += currentChar;
        }
    }
    return masked;
}

// Replaces every occurrence of the repository base URL with the facade's
// own base URL within a searchset Bundle's links and entry fullUrls.
isolated function rewriteBundleUrls(r4:Bundle bundle) returns r4:Bundle {
    r4:BundleLink[]? links = bundle.link;
    if links is r4:BundleLink[] {
        bundle.link = from r4:BundleLink link in links
            select {relation: link.relation, url: replaceBaseUrl(link.url)};
    }

    r4:BundleEntry[]? entries = bundle.entry;
    if entries is r4:BundleEntry[] {
        foreach r4:BundleEntry entry in entries {
            string? fullUrl = entry.fullUrl;
            if fullUrl is string {
                entry.fullUrl = replaceBaseUrl(fullUrl);
            }
        }
        bundle.entry = entries;
    }

    return bundle;
}

// Replaces the repository base URL prefix in the given URL with the facade base URL.
isolated function replaceBaseUrl(string url) returns string {
    if url.startsWith(fhirServerUrl) {
        return facadeBaseUrl + url.substring(fhirServerUrl.length());
    }
    return url;
}

// Converts a searchset Bundle entry's resource to an international401:Patient,
// applies the facade changes, and writes it back into the entry.
isolated function applyFacadeChangesToEntry(r4:BundleEntry entry) returns r4:BundleEntry|error {
    anydata|r4:FHIRWireFormat? entryResource = entry?.'resource;
    if entryResource is () {
        return entry;
    }

    json resourceJson = check entryResource.cloneWithType(json);
    international401:Patient patient = check resourceJson.cloneWithType(international401:Patient);
    international401:Patient changedPatient = applyFacadeChanges(patient);
    entry.'resource = changedPatient.toJson();
    return entry;
}
