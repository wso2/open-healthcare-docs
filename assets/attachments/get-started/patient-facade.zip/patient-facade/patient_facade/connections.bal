import ballerinax/health.clients.fhir;

// Client used to call the upstream WSO2 FHIR Server repository.
final fhir:FHIRConnector fhirServerClient = check new ({
    baseURL: fhirServerUrl
});
