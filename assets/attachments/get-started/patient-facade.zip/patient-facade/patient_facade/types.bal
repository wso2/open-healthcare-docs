// Constants identifying the facade as the source of changes applied to
// every Patient resource returned by this service.
const string FACADE_TAG_SYSTEM = "http://wso2.com/fhir/facade/source";
const string FACADE_TAG_CODE = "patient-api-facade";

// FHIR identifier system that must be stripped from outgoing Patient resources.
const string US_SSN_IDENTIFIER_SYSTEM = "http://hl7.org/fhir/sid/us-ssn";
