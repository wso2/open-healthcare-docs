import ballerina/log;
import ballerina/time;
import ballerina/uuid;
import ballerinax/health.clients.fhir;

// Routes each FHIR interaction to the Epic or Cerner connector for the given EMR.

# Reads a Patient from one EMR.
#
# + emr - source EMR
# + patientId - patient logical id
# + return - FHIR response or error
function readPatient(EmrSystem emr, string patientId) returns fhir:FHIRResponse|fhir:FHIRError {
    if emr == EPIC {
        return epicClient->getPatientById(patientId);
    }
    return cernerClient->getPatientById(patientId);
}

# Searches Patients by demographics in one EMR.
#
# + emr - source EMR
# + family - family name
# + given - given name
# + birthdate - date of birth
# + return - FHIR searchset response or error
function findPatients(EmrSystem emr, string? family, string? given, string? birthdate)
        returns fhir:FHIRResponse|fhir:FHIRError {
    if emr == EPIC {
        return epicClient->searchPatient(family = family, given = given, birthdate = birthdate);
    }
    return cernerClient->searchPatient(family = family, given = given, birthdate = birthdate);
}

# Searches a patient's Conditions in one EMR.
#
# + emr - source EMR
# + patientId - patient logical id
# + return - FHIR searchset response or error
function searchConditions(EmrSystem emr, string patientId) returns fhir:FHIRResponse|fhir:FHIRError {
    if emr == EPIC {
        return epicClient->searchCondition(patient = patientId);
    }
    return cernerClient->searchCondition(patient = patientId);
}

# Searches a patient's MedicationRequests in one EMR.
#
# + emr - source EMR
# + patientId - patient logical id
# + return - FHIR searchset response or error
function searchMedications(EmrSystem emr, string patientId) returns fhir:FHIRResponse|fhir:FHIRError {
    if emr == EPIC {
        return epicClient->searchMedicationRequest(patient = patientId);
    }
    return cernerClient->searchMedicationRequest(patient = patientId);
}

# Searches a patient's AllergyIntolerances in one EMR.
#
# + emr - source EMR
# + patientId - patient logical id
# + return - FHIR searchset response or error
function searchAllergies(EmrSystem emr, string patientId) returns fhir:FHIRResponse|fhir:FHIRError {
    if emr == EPIC {
        return epicClient->searchAllergyIntolerance(patient = patientId);
    }
    return cernerClient->searchAllergyIntolerance(patient = patientId);
}

# Searches a patient's Observations of one category in one EMR.
#
# + emr - source EMR
# + patientId - patient logical id
# + category - observation category, for example vital-signs or laboratory
# + return - FHIR searchset response or error
function searchObservations(EmrSystem emr, string patientId, string category)
        returns fhir:FHIRResponse|fhir:FHIRError {
    if emr == EPIC {
        return epicClient->searchObservation(patient = patientId, category = category);
    }
    return cernerClient->searchObservation(patient = patientId, category = category);
}

# Looks a patient id up in both EMRs in parallel and combines the outcomes.
#
# + patientId - patient logical id
# + return - combined lookup result (never fails; misses become warnings)
function lookupPatientEverywhere(string patientId) returns UnifiedPatientResult {
    log:printInfo("Fanning out patient lookup to Epic and Cerner", patientId = patientId);
    future<PatientSummary|error> epicFuture = start fetchPatientSummary(emr = EPIC, patientId = patientId);
    future<PatientSummary|error> cernerFuture = start fetchPatientSummary(emr = CERNER, patientId = patientId);

    string[] foundIn = [];
    PatientSummary[] records = [];
    string[] warnings = [];
    PatientSummary|error epicPatient = wait epicFuture;
    if epicPatient is PatientSummary {
        foundIn.push(EPIC);
        records.push(epicPatient);
    } else {
        warnings.push(string `epic: ${epicPatient.message()}`);
    }
    PatientSummary|error cernerPatient = wait cernerFuture;
    if cernerPatient is PatientSummary {
        foundIn.push(CERNER);
        records.push(cernerPatient);
    } else {
        warnings.push(string `cerner: ${cernerPatient.message()}`);
    }
    log:printInfo("Combined patient lookup ready", patientId = patientId, foundIn = foundIn.toString());
    return {queriedId: patientId, foundIn, records, warnings};
}

# Fetches a Patient resource from one EMR and maps it to a summary.
#
# + emr - source EMR
# + patientId - patient logical id
# + return - patient summary or an error
function fetchPatientSummary(EmrSystem emr, string patientId) returns PatientSummary|error {
    decimal startSeconds = time:monotonicNow();
    log:printInfo("EMR request: Patient read", emr = emr, patientId = patientId);
    fhir:FHIRResponse|fhir:FHIRError fhirResponse = readPatient(emr = emr, patientId = patientId);
    decimal elapsedMs = (time:monotonicNow() - startSeconds) * 1000;
    if fhirResponse is fhir:FHIRError {
        log:printWarn("EMR response: Patient read failed", emr = emr, patientId = patientId,
                elapsedMs = elapsedMs, reason = fhirResponse.message());
        return fhirResponse;
    }
    json patientJson = check fhirResponse.'resource.ensureType();
    log:printInfo("EMR response: Patient read", emr = emr, httpStatus = fhirResponse.httpStatusCode,
            elapsedMs = elapsedMs, rawFhir = jsonSnippet(payload = patientJson));
    return toPatientSummary(patientJson = patientJson, sourceEmr = emr);
}

# Searches patients by demographics in one EMR.
#
# + emr - source EMR
# + family - family name
# + given - given name
# + birthdate - date of birth
# + return - matching patient summaries or an error
function searchPatients(EmrSystem emr, string? family, string? given, string? birthdate)
        returns PatientSummary[]|error {
    decimal startSeconds = time:monotonicNow();
    log:printInfo("EMR request: Patient search", emr = emr, family = family,
            given = given, birthdate = birthdate);
    fhir:FHIRResponse|fhir:FHIRError fhirResponse = findPatients(emr = emr,
            family = family, given = given, birthdate = birthdate);
    decimal elapsedMs = (time:monotonicNow() - startSeconds) * 1000;
    if fhirResponse is fhir:FHIRError {
        log:printWarn("EMR response: Patient search failed", emr = emr,
                elapsedMs = elapsedMs, reason = fhirResponse.message());
        return fhirResponse;
    }
    json bundleJson = check fhirResponse.'resource.ensureType();
    PatientSummary[] patientSummaries = [];
    foreach json entryResource in check bundleToResources(bundleJson = bundleJson) {
        map<json> resourceMap = check entryResource.ensureType();
        if resourceMap["resourceType"] != "Patient" {
            continue;
        }
        PatientSummary|error patientSummary = toPatientSummary(patientJson = entryResource, sourceEmr = emr);
        if patientSummary is PatientSummary {
            patientSummaries.push(patientSummary);
        }
    }
    log:printInfo("EMR response: Patient search", emr = emr, httpStatus = fhirResponse.httpStatusCode,
            elapsedMs = elapsedMs, matches = patientSummaries.length());
    return patientSummaries;
}

# Builds the cross-EMR Patient-360 view: aggregates clinical data from every EMR
# where the id resolves, then demographically links the other EMR's record.
#
# + patientId - patient logical id
# + return - unified Patient-360 or an error
function buildUnifiedPatient360(string patientId) returns UnifiedPatient360|error {
    UnifiedPatientResult lookup = lookupPatientEverywhere(patientId = patientId);
    if lookup.foundIn.length() == 0 {
        return error(string `Patient '${patientId}' was not found in any connected EMR`);
    }
    string[] warnings = [];
    Patient360[] summaries = [];
    string? linkedVia = ();
    string primaryEmr = lookup.foundIn[0];

    foreach string foundEmr in lookup.foundIn {
        EmrSystem foundSystem = foundEmr == EPIC ? EPIC : CERNER;
        summaries.push(check buildPatient360(emr = foundSystem, patientId = patientId));
    }
    if lookup.foundIn.length() == 2 {
        linkedVia = "same patient id present in both EMRs";
    } else {
        // Link the same person in the other EMR by demographics and aggregate there too.
        EmrSystem otherEmr = primaryEmr == EPIC ? CERNER : EPIC;
        PatientSummary primaryPatient = summaries[0].patient;
        string? familyName = primaryPatient.family;
        string? birthDate = primaryPatient.birthDate;
        if familyName is string && birthDate is string {
            log:printInfo("Attempting cross-EMR demographic link", targetEmr = otherEmr,
                    family = familyName, birthdate = birthDate);
            PatientSummary[]|error linkCandidates = searchPatients(emr = otherEmr,
                    family = familyName, given = (), birthdate = birthDate);
            if linkCandidates is error {
                warnings.push(string `cross-EMR link search failed: ${linkCandidates.message()}`);
            } else if linkCandidates.length() > 0 {
                linkedVia = "family name + birthDate demographic match";
                log:printInfo("Cross-EMR link established", targetEmr = otherEmr,
                        linkedPatientId = linkCandidates[0].patientId, candidates = linkCandidates.length());
                Patient360|error linkedSummary = buildPatient360(emr = otherEmr,
                        patientId = linkCandidates[0].patientId);
                if linkedSummary is Patient360 {
                    summaries.push(linkedSummary);
                } else {
                    warnings.push(string `linked record aggregation failed: ${linkedSummary.message()}`);
                }
            } else {
                warnings.push(string `no matching patient found in ${otherEmr} by demographics`);
            }
        } else {
            warnings.push("insufficient demographics on the primary record to attempt a cross-EMR link");
        }
    }

    UnifiedPatient360 unified360 = {
        queriedId: patientId,
        primaryEmr,
        summaries,
        warnings
    };
    if linkedVia is string {
        unified360.linkedVia = linkedVia;
    }
    return unified360;
}

# Aggregates demographics, conditions, medications, allergies, vitals and labs
# for a patient from one EMR. Individual section failures (e.g. missing scopes)
# become warnings instead of failing the whole aggregation.
#
# + emr - source EMR
# + patientId - patient logical id
# + return - aggregated Patient-360 view or an error
function buildPatient360(EmrSystem emr, string patientId) returns Patient360|error {
    PatientSummary patientSummary = check fetchPatientSummary(emr = emr, patientId = patientId);
    string[] warnings = [];
    log:printInfo("Fanning out clinical section searches", emr = emr, patientId = patientId,
            sections = "conditions, medications, allergies, vitals, labResults");

    // Fan out all clinical section searches to the EMR in parallel.
    future<fhir:FHIRResponse|fhir:FHIRError> conditionFuture = start searchConditions(emr = emr, patientId = patientId);
    future<fhir:FHIRResponse|fhir:FHIRError> medicationFuture = start searchMedications(emr = emr, patientId = patientId);
    future<fhir:FHIRResponse|fhir:FHIRError> allergyFuture = start searchAllergies(emr = emr, patientId = patientId);
    future<fhir:FHIRResponse|fhir:FHIRError> vitalsFuture = start searchObservations(emr = emr,
            patientId = patientId, category = "vital-signs");
    future<fhir:FHIRResponse|fhir:FHIRError> labsFuture = start searchObservations(emr = emr,
            patientId = patientId, category = "laboratory");

    ConditionSummary[] conditions = [];
    fhir:FHIRResponse|fhir:FHIRError conditionResponse = wait conditionFuture;
    json? conditionBundle = sectionBundle(emr = emr, sectionResponse = conditionResponse,
            sectionName = "conditions", warnings = warnings);
    if conditionBundle !is () {
        ConditionSummary[]|error mappedConditions = toConditionSummaries(bundleJson = conditionBundle);
        if mappedConditions is ConditionSummary[] {
            conditions = mappedConditions;
        } else {
            warnings.push(string `conditions: ${mappedConditions.message()}`);
        }
    }

    MedicationSummary[] medications = [];
    fhir:FHIRResponse|fhir:FHIRError medicationResponse = wait medicationFuture;
    json? medicationBundle = sectionBundle(emr = emr, sectionResponse = medicationResponse,
            sectionName = "medications", warnings = warnings);
    if medicationBundle !is () {
        MedicationSummary[]|error mappedMedications = toMedicationSummaries(bundleJson = medicationBundle);
        if mappedMedications is MedicationSummary[] {
            medications = mappedMedications;
        } else {
            warnings.push(string `medications: ${mappedMedications.message()}`);
        }
    }

    AllergySummary[] allergies = [];
    fhir:FHIRResponse|fhir:FHIRError allergyResponse = wait allergyFuture;
    json? allergyBundle = sectionBundle(emr = emr, sectionResponse = allergyResponse,
            sectionName = "allergies", warnings = warnings);
    if allergyBundle !is () {
        AllergySummary[]|error mappedAllergies = toAllergySummaries(bundleJson = allergyBundle);
        if mappedAllergies is AllergySummary[] {
            allergies = mappedAllergies;
        } else {
            warnings.push(string `allergies: ${mappedAllergies.message()}`);
        }
    }

    ObservationSummary[] vitals = [];
    fhir:FHIRResponse|fhir:FHIRError vitalsResponse = wait vitalsFuture;
    json? vitalsBundle = sectionBundle(emr = emr, sectionResponse = vitalsResponse,
            sectionName = "vitals", warnings = warnings);
    if vitalsBundle !is () {
        ObservationSummary[]|error mappedVitals = toObservationSummaries(bundleJson = vitalsBundle);
        if mappedVitals is ObservationSummary[] {
            vitals = mappedVitals;
        } else {
            warnings.push(string `vitals: ${mappedVitals.message()}`);
        }
    }

    ObservationSummary[] labResults = [];
    fhir:FHIRResponse|fhir:FHIRError labsResponse = wait labsFuture;
    json? labsBundle = sectionBundle(emr = emr, sectionResponse = labsResponse,
            sectionName = "labResults", warnings = warnings);
    if labsBundle !is () {
        ObservationSummary[]|error mappedLabs = toObservationSummaries(bundleJson = labsBundle);
        if mappedLabs is ObservationSummary[] {
            labResults = mappedLabs;
        } else {
            warnings.push(string `labResults: ${mappedLabs.message()}`);
        }
    }

    log:printInfo("Patient-360 aggregation complete", emr = emr, patientId = patientId,
            conditions = conditions.length(), medications = medications.length(),
            allergies = allergies.length(), vitals = vitals.length(),
            labResults = labResults.length(), warnings = warnings.length());
    return {
        patient: patientSummary,
        conditions,
        medications,
        allergies,
        vitals,
        labResults,
        warnings
    };
}

# Unwraps one clinical section's search response, converting failures into warnings.
#
# + emr - EMR the section was requested from (for logging)
# + sectionResponse - raw FHIR search response or connector error
# + sectionName - section label used in warnings
# + warnings - warning accumulator
# + return - the section's Bundle payload, or () when the section failed
function sectionBundle(EmrSystem emr, fhir:FHIRResponse|fhir:FHIRError sectionResponse,
        string sectionName, string[] warnings) returns json? {
    if sectionResponse is fhir:FHIRError {
        log:printWarn("EMR response: section search failed", emr = emr, section = sectionName,
                reason = sectionResponse.message());
        warnings.push(string `${sectionName}: ${sectionResponse.message()}`);
        return ();
    }
    json|error bundleJson = sectionResponse.'resource.ensureType();
    if bundleJson is error {
        warnings.push(string `${sectionName}: unexpected non-JSON response`);
        return ();
    }
    log:printInfo("EMR response: section search", emr = emr, section = sectionName,
            httpStatus = sectionResponse.httpStatusCode,
            resourceCount = countBundleEntries(bundleJson = bundleJson));
    return bundleJson;
}

# Executes a cross-EMR referral: source Patient-360 pull and target patient match.
#
# + referralRequest - referral instruction
# + return - assembled referral packet or an error
function processReferral(ReferralRequest referralRequest) returns ReferralPacket|error {
    string referralId = uuid:createType4AsString();
    log:printInfo("Processing referral", referralId = referralId,
            sourceEmr = referralRequest.sourceEmr, targetEmr = referralRequest.targetEmr,
            patientId = referralRequest.patientId);
    Patient360 clinicalSummary = check buildPatient360(emr = referralRequest.sourceEmr,
            patientId = referralRequest.patientId);
    PatientSummary sourcePatient = clinicalSummary.patient;
    string[] warnings = [];

    string? familyName = sourcePatient.family;
    string? givenName = sourcePatient.given;

    PatientMatch[] targetMatches = [];
    if familyName is string && sourcePatient.birthDate is string {
        PatientSummary[]|error candidates = searchPatients(emr = referralRequest.targetEmr,
                family = familyName, given = (), birthdate = sourcePatient.birthDate);
        if candidates is error {
            warnings.push(string `target match search failed: ${candidates.message()}`);
        } else {
            foreach PatientSummary candidate in candidates {
                targetMatches.push({patient: candidate, matchedOn: "family name + birthDate"});
            }
        }
    } else {
        warnings.push("insufficient demographics on source record to attempt a match");
        if givenName is () {
            log:printWarn("Source record has no structured given name", referralId = referralId);
        }
    }

    string matchOutcome = targetMatches.length() > 0 ? "MATCH_FOUND" : "NO_MATCH";
    log:printInfo("Referral packet assembled", referralId = referralId,
            matchOutcome = matchOutcome, targetMatches = targetMatches.length());
    return {
        referralId,
        reason: referralRequest.reason,
        sourceEmr: referralRequest.sourceEmr,
        targetEmr: referralRequest.targetEmr,
        clinicalSummary,
        targetMatches,
        matchOutcome,
        warnings
    };
}
